//No. of Users Graph
var chart = AmCharts.makeChart("usersNo", {
    "type": "serial",
    "theme": "light",
    "titles": [{
    "text": "Daily Active Users",
    "bold": false
  }],
    "marginTop":0,
    "marginRight": 80,
    "dataDateFormat":"DD-MM-YY",
    "valueAxes": [{
        "id": "v1",
        "axisAlpha": 0,
        "position": "left",
        "ignoreAxisWidth":false
    }],
    "balloon": {
        "borderThickness": 1,
        "shadowAlpha": 0
    },
    "graphs": [{
      "id":"g1",
     "balloonText": "[[category]]<br><b><span style='font-size:14px;'>[[value]]</span></b>",
     "bullet": "round",
     "bulletSize": 8,
     "bulletColor": "#000092",
     "lineColor": "#29ABE2",
     "lineThickness": 1,
     "negativeLineColor": "#637bb6",
     "type": "smoothedLine",
     "fillAlphas": 0.2,
     "fillColorsField": "lineColor",
     "valueField": "Users"
    }],

    "chartCursor": {
        "pan": true,
        "valueLineEnabled": true,
        "valueLineBalloonEnabled": true,
        "cursorAlpha":1,
        "cursorColor":"#000092",
        "limitToGraph":"g1",
        "valueLineAlpha":0.2,
        "valueZoomable":true
    },
   //  "valueScrollbar":{
   //    "visible": false,
   //   "oppositeAxis":false,
   //   "offset":50,
   //   "scrollbarHeight":10
   // },

    "categoryField": "DayIndex",
    "categoryAxis": {
        "dashLength": 1,
        "minorGridEnabled": true
    },
    "export": {
        "enabled": true
    },
    "dataProvider": [
      {
        "DayIndex": "6/21/18",
        "Users": 199
      },
      {
        "DayIndex": "6/22/18",
        "Users": 193
      },
      {
        "DayIndex": "6/23/18",
        "Users": 101
      },
      {
        "DayIndex": "6/24/18",
        "Users": 92
      },
      {
        "DayIndex": "6/25/18",
        "Users": 245
      },
      {
        "DayIndex": "6/26/18",
        "Users": 221
      },
      {
        "DayIndex": "6/27/18",
        "Users": 222
      }
    ]
});


//Browsers Pie Chart
AmCharts.makeChart( "browsers", {
  "type"    : "pie",
  "theme": "light",
  "titleField"  : "Browser",
  "valueField"  : "Users",
  "labelText": "",
  "colorField": "color",
  "balloon": {
    "fixedPosition": false,

  },
  "innerRadius": "50%",
  "legend":{
    "position":"right",
    "marginRight": 20,
    "autoMargins": true,
    "valueAlign": "left",
    "labelText":"[[title]]:"

  },

  "dataProvider"  : [
    {
      "Browser": "Chrome",
      "Users": 474,
      "NewUsers": 191,
      "Sessions": 680,
      "BounceRate": "73.97%",
      "PagesSession": 1.52,
      "AvgSessionDuration": "00:02:45",
      "GoalConversionRate": "0.00%",
      "GoalCompletions": 0,
      "GoalValue": "$0.00"
    },
    {
      "Browser": "Internet Explorer",
      "Users": 211,
      "NewUsers": 92,
      "Sessions": 294,
      "BounceRate": "80.27%",
      "PagesSession": 1.35,
      "AvgSessionDuration": "00:02:14",
      "GoalConversionRate": "0.00%",
      "GoalCompletions": 0,
      "GoalValue": "$0.00"
    },
    {
      "Browser": "Safari",
      "Users": 169,
      "NewUsers": 89,
      "Sessions": 226,
      "BounceRate": "73.45%",
      "PagesSession": 1.51,
      "AvgSessionDuration": "00:01:37",
      "GoalConversionRate": "0.00%",
      "GoalCompletions": 0,
      "GoalValue": "$0.00"
    },
    {
      "Browser": "Edge",
      "Users": 84,
      "NewUsers": 38,
      "Sessions": 114,
      "BounceRate": "85.09%",
      "PagesSession": 1.4,
      "AvgSessionDuration": "00:02:06",
      "GoalConversionRate": "0.00%",
      "GoalCompletions": 0,
      "GoalValue": "$0.00"
    },
    {
      "Browser": "Firefox",
      "Users": 64,
      "New Users": 32,
      "Sessions": 92,
      "BounceRate": "80.43%",
      "PagesSession": 1.34,
      "AvgSessionDuration": "00:01:14",
      "GoalConversionRate": "0.00%",
      "GoalCompletions": 0,
      "GoalValue": "$0.00"
    },
    {
      "Browser": "Samsung Internet",
      "Users": 2,
      "New Users": 0,
      "Sessions": 2,
      "BounceRate": "50.00%",
      "PagesSession": 2.5,
      "AvgSessionDuration": "00:00:52",
      "GoalConversionRate": "0.00%",
      "GoalCompletions": 0,
      "GoalValue": "$0.00"
    },
    {
      "Browser": "Amazon Silk",
      "Users": 1,
      "NewUsers": 1,
      "Sessions": 1,
      "BounceRate": "0.00%",
      "PagesSession": 12,
      "AvgSessionDuration": "00:15:38",
      "GoalConversionRate": "0.00%",
      "GoalCompletions": 0,
      "GoalValue": "$0.00"
    },
    {
      "Browser": "Opera",
      "Users": 1,
      "NewUsers": 0,
      "Sessions": 4,
      "BounceRate": "100.00%",
      "PagesSession": 1,
      "AvgSessionDuration": "00:00:00",
      "GoalConversionRate": "0.00%",
      "GoalCompletions": 0,
      "GoalValue": "$0.00"
    }
  ]
});

//Devices Pie Chart
AmCharts.makeChart( "devices", {
  "type"    : "pie",
  "theme": "light",
  "titleField"  : "category",
  "valueField"  : "column-1",
  "colorField": "color",
  "labelText": "",
  "balloon": {
    "fixedPosition": false
  },
  "innerRadius": "50%",
  "legend":{
  "position":"right",
      "marginRight": 20,
      "autoMargins": true,
      "valueAlign": "left",
      "labelText":"[[title]]:"
   	/*"position":"bottom",
    "marginTop":0,
    "valueAlign": "left",
    "labelText":"[[title]]:"*/
  },
  "dataProvider"  : [
    {
      "category": "Desktop",
      "column-1": 879,
       "color": "#67B7DC"
    },
    {
      "category": "Tablets",
      "column-1": 67,
      "color":"#FDD501"
    },
    {
      "category": "Mobile",
      "column-1": 60,
      "color":"#85B762"
    }
  ]
});
// EDELIVERY PAGE
// EDELIVERY PAGE
// Graph 1 on EDelivery page
var chartEDelivery = AmCharts.makeChart("edeliveryChart", {
        "type": "serial",
        "categoryField": "category",
        "startDuration": 1,
        "color": "#07079C",
        "autoMargins": false,
        "marginLeft": 250,
        "marginRight": 8,
        "marginTop": 40,
        "marginBottom": 26,
        "fontSize": 8,
        "categoryAxis": {
            "gridPosition": "start"
        },
        "trendLines": [],
        "graphs": [{
            "balloonText": "[[title]]:[[value]]",
            "fillAlphas": 1,
            "fixedColumnWidth": 5,
            "fontSize": 0,
            "id": "2016",
            "title": "2016",
            "type": "column",
            "valueField": "2016"
        }, {
            "balloonText": "[[title]]:[[value]]",
            "fillAlphas": 1,
            "fixedColumnWidth": 5,
            "fontSize": 0,
            "id": "2017",
            "title": "2017",
            "type": "column",
            "valueField": "2017"
        }, {
            "balloonText": "[[title]]:[[value]]",
            "fillAlphas": 1,
            "fillColors": "#0039E6",
            "fixedColumnWidth": 5,
            "fontSize": 0,
            "id": "2018",
            "lineColor": "#0039E6",
            "title": "2018",
            "type": "column",
            "valueField": "2018"
        }],
        "guides": [],
        "valueAxes": [{
            "id": "ValueAxis-1",
            "maximum": 800000,
            "minimum": 0,
            "title": ""

        }],
        "legend": {
    "maxColumns": 1,
    "position": "right",
        // "balloon": {},
        // "legend": {
        //   "align": "left",
        //     "enabled": true,
        //     "labelWidth": 0,
            "useGraphSettings": true
        },
        "allLabels": [
      		{
      			"text": "E-Delivery Emails Sent",
      			"bold": true,
            "size":18,
      			"x": 10,
      			"y": 10,
            "color":"#353C70"
      		}
      	],
        "dataProvider": [{
            "2016": 200000,
            "2017": 250000,
            "2018": 300000,
            "category": "January"
        }, {
            "2016": 300000,
            "2017": 750000,
            "2018": 400000,
            "category": "February"
        }, {
            "2016": 750000,
            "2017": 350000,
            "2018": 100000,
            "category": "March"
        }, {
            "2016": 250000,
            "2017": 475000,
            "2018": 700000,
            "category": "April"
        }, {
            "2016": 490005,
            "2017": 260000,
            "2018": 475000,
            "category": "May"
        }, {
            "2016": 375000,
            "2017": 415000,
            "2018": 350000,
            "category": "June"
        }, {
            "2016": 160000,
            "2017": 435000,
            "2018": 0,
            "category": "July"
        }, {
            "2016": 615000,
            "2017": 650000,
            "2018": 0,
            "category": "August"
        }, {
            "2016": 640000,
            "2017": 390000,
            "2018": 0,
            "category": "September"
        }, {
            "2016": 235000,
            "2017": 55000,
            "2018": 0,
            "category": "October"
        }, {
            "2016": 300000,
            "2017": 600000,
            "2018": 0,
            "category": "November"
        }, {
            "2016": 275000,
            "2017": 62000,
            "2018": 0,
            "category": "December"
        }]
    })
// Graph 2 on EDelivery Page
var chart2 = AmCharts.makeChart("edeliveryHS", {
  "type": "serial",
  "addClassNames": true,
  "theme": "light",
  "autoMargins": false,
  "marginLeft": 250,
  "marginRight": 8,
  "marginTop": 40,
  "marginBottom": 26,
  "balloon": {
    "adjustBorderColor": false,
    "horizontalPadding": 10,
    "verticalPadding": 8,
    "color": "#ffffff"
  },
  "allLabels": [
    {
      "text": "Hard and Soft Bounces",
      "bold": true,
      "size":18,
      "x": 10,
      "y": 10,
      "color":"#353C70"
    }
  ],
  "dataProvider": [ {
    'month':'Jan',
    'signUps': Math.random() * 1000,
    'hardBounces': Math.random() * 100,
    'softBounces': Math.random() * 100
  },
  {
    'month':'Feb',
    'signUps': Math.random() * 1000,
    'hardBounces': Math.random() * 100,
    'softBounces': Math.random() * 100
  },
  {
    'month':'March',
    'signUps': Math.random() * 1000,
    'hardBounces': Math.random() * 100,
    'softBounces': Math.random() * 100
  },
  {
    'month':'April',
    'signUps': Math.random() * 1000,
    'hardBounces': Math.random() * 100,
    'softBounces': Math.random() * 100
  },
  {
    'month':'May',
    'signUps': Math.random() * 1000,
    'hardBounces': Math.random() * 100,
    'softBounces': Math.random() * 100
  },
  {
    'month':'June',
    'signUps': Math.random() * 1000,
    'hardBounces': Math.random() * 100,
    'softBounces': Math.random() * 100
  },
  {
    'month':'July',
    'signUps': Math.random() * 1000,
    'hardBounces': Math.random() * 100,
    'softBounces': Math.random() * 100
  },
  {
    'month':'Aug',
    'signUps': Math.random() * 1000,
    'hardBounces': Math.random() * 100,
    'softBounces': Math.random() * 100
  },
  {
    'month':'Sep',
    'signUps': Math.random() * 1000,
    'hardBounces': Math.random() * 100,
    'softBounces': Math.random() * 100
  },
  {
    'month':'Oct',
    'signUps': Math.random() * 1000,
    'hardBounces': Math.random() * 100,
    'softBounces': Math.random() * 100
  },
  {
    'month':'Nov',
    'signUps': Math.random() * 1000,
    'hardBounces': Math.random() * 100,
    'softBounces': Math.random() * 100
  },
  {
    'month':'Dec',
    'signUps': Math.random() * 1000,
    'hardBounces': Math.random() * 100,
    'softBounces': Math.random() * 100
  }],
  "valueAxes": [ {
    "axisAlpha": 0,
    "position": "left"
  } ],
  "startDuration": 1,
  "graphs": [ {
    "alphaField": "alpha",
    "balloonText": "<span style='font-size:12px;'>[[title]] in [[category]]:<br><span style='font-size:20px;'>[[value]]</span> [[additional]]</span>",
    "fillAlphas": 1,
    "title": "Total Bounces",
    "type": "column",
    "valueField": "hardBounces",
    "dashLengthField": "dashLengthColumn"
  }, {
    "id": "graph2",
    "balloonText": "<span style='font-size:12px;'>[[title]] in [[category]]:<br><span style='font-size:20px;'>[[value]]</span> [[additional]]</span>",
    "bullet": "round",
    "lineThickness": 3,
    "bulletSize": 7,
    "bulletBorderAlpha": 1,
    "bulletColor": "#FFFFFF",
    "useLineColorForBulletBorder": true,
    "bulletBorderThickness": 3,
    "fillAlphas": 0,
    "lineAlpha": 1,
    "title": "Soft Bounces",
    "valueField": "softBounces",
    "dashLengthField": "dashLengthLine"
  }, {
    "id": "graph3",
    "balloonText": "<span style='font-size:12px;'>[[title]] in [[category]]:<br><span style='font-size:20px;'>[[value]]</span> [[additional]]</span>",
    "bullet": "round",
    "lineThickness": 3,
    "bulletSize": 7,
    "bulletBorderAlpha": 1,
    "bulletColor": "#FFFFFF",
    "useLineColorForBulletBorder": true,
    "bulletBorderThickness": 3,
    "fillAlphas": 0,
    "lineAlpha": 1,
    "title": "Hard Bounces",
    "valueField": "hardBounces",
    "dashLengthField": "dashLengthLine"
  }  ],
  "categoryField": "month",
  "categoryAxis": {
    "gridPosition": "start",
    "axisAlpha": 0,
    "tickLength": 0
  },
  "legend": {
    "maxColumns": 1,
    "position": "right",
    "valueAxis":"Y axis",
      // "allLabels": [],
      // "balloon": {},
      // "legend": {
      // 	"enabled": true,
        "useGraphSettings": true
      },
      "export": {
        "enabled": true
      }
});
//Graph 3 on EDelivery Page
var EDSigns = AmCharts.makeChart("test", {
	"type": "serial",
  "autoMargins": false,
  "marginLeft": 250,
  "marginRight": 8,
  "marginTop": 40,
  "marginBottom": 40,
	"categoryField": "month",
	"startDuration": 1,
	"categoryAxis": {
		"autoRotateAngle": 1.8,
		"gridPosition": "start",
		"labelRotation": 52.2
	},
	"trendLines": [],
	"graphs": [
		{
			"balloonText": "[[title]] of [[category]]:[[value]]",
			"fillAlphas": 1,
			"fillColors": "#F4C06D",
			"id": "AmGraph-1",
			"lineColor": "#F4C06D",
			"title": "2017",
			"type": "column",
			"valueField": "2017"
		},
		{
			"balloonText": "[[title]] of [[category]]:[[value]]",
			"fillAlphas": 1,
			"fillColors": "#526198",
			"id": "AmGraph-2",
			"lineColor": "#526198",
			"title": "2018",
			"type": "column",
			"valueField": "2018"
		}
	],
	"guides": [],
	"valueAxes": [
		{
			"id": "ValueAxis-1",
			"title": ""
		}
	],
  "legend": {
"maxColumns": 1,
"position": "right",
	// "allLabels": [],
	// "balloon": {},
	// "legend": {
	// 	"enabled": true,
		"useGraphSettings": true
	},
  "allLabels": [
    {
      "text": "E-Delivery Sign Ups",
      "bold": true,
      "size":18,
      "x": 10,
      "y": 10,
      "color":"#353C70"
    }
  ],
	"dataProvider": [
		{
			"2017": "2000",
			"2018": 1400,
			"month": "Jan"
		},
		{
			"2017": "1000",
			"2018": 1200,
			"month": "Feb"
		},
		{
			"2017": "400",
			"2018": 1500,
			"month": "March"
		},
		{
			"2017": 600,
			"2018": 766,
			"month": "April"
		},
		{
			"2017": "900",
			"2018": 1200,
			"month": "May"
		},
		{
			"2017": "2100",
			"2018": 2150,
			"month": "June"
		},
		{
			"2017": "780",
			"2018": 980,
			"month": "July"
		},
		{
			"2017": "300",
			"2018": 500,
			"month": "Aug"
		},
		{
			"2017": "540",
			"2018": 670,
			"month": "Sep"
		},
		{
			"2017": "860",
			"2018": 960,
			"month": "Oct"
		},
		{
			"2017": "902",
			"2018": 502,
			"month": "Nov"
		},
		{
			"2017": "362",
			"2018": 262,
			"month": "Dec"
		}
	]
});

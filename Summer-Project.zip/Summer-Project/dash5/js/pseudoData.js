// LAST UPDATED
// Will be between 1 and 5 minutes
var lastUpdated = setInterval(function() {
  var lastUpdatedMin = Math.round(Math.random() * 5) + 1;
}, 2000);
/* Overall variables */
var healthScore = 100;
var unavailableItems = 0;
var overallAvgLoad = 0;
var avgPageViews = 0;

/*JSON OBJECTS FOR SITE USERS */
var currentUsers = setInterval(function() {
    var randomNumber = Math.round(Math.random() * 300) + 1;
    $("#users").text("Current Users: " + randomNumber);
}, 15000);

var usersWeekly = [
  {
    "DayIndex": "6/21/18",
    "Users": 199
  },
  {
    "DayIndex": "6/22/18",
    "Users": 193
  },
  {
    "DayIndex": "6/23/18",
    "Users": 101
  },
  {
    "DayIndex": "6/24/18",
    "Users": 92
  },
  {
    "DayIndex": "6/25/18",
    "Users": 245
  },
  {
    "DayIndex": "6/26/18",
    "Users": 221
  },
  {
    "DayIndex": "6/27/18",
    "Users": 222
  }
]

/*JSON OBJECT FOR LOAD TIME FOR DAY*/
/* LOAD TIMES */

var avgLoadPerDay = [
  {
    "DayIndex": "6/21/18",
    "Avg": 3.49
  },
  {
    "DayIndex": "6/22/18",
    "Avg": 0
  },
  {
    "DayIndex": "6/23/18",
    "Avg": 5.27
  },
  {
    "DayIndex": "6/24/18",
    "Avg": 4.65
  },
  {
    "DayIndex": "6/25/18",
    "Avg": 3.73
  },
  {
    "DayIndex": "6/26/18",
    "Avg": 0
  },
  {
    "DayIndex": "6/27/18",
    "Avg": 4.74
  }
];

avgLoadPerDay.forEach(function(entry) {
  var date = entry.DayIndex;
  var loadTime = entry.Avg;
  overallAvgLoad += loadTime;
  if(healthScore > 0) {
    if(loadTime > 8) {
      healthScore = healthScore - 10;
    }
  }
  $('#loadTime').append('<b>'+date+': ' + loadTime.toFixed(2) + ' seconds' + '</b><br / >')
})
overallAvgLoad /= 7;
console.log("Overall Avg Load: " + overallAvgLoad);

/*JSON OBJECTS FOR LINK AND PAGES (LOAD TIME, AVAIL, ETC) */

/* PAGES */
var availObjectPages =
[
  {
    'name': 'equitable0078',
    'avail':  Math.random() * 5,
    'Timestamp': '3pm'
  },
  {
    'name': 'default0079',
    'avail': Math.random() * 5,
    'Timestamp': '3pm'
  },
  {
    'name': 'invest123456',
    'avail':  Math.random() * 5,
    'Timestamp': '3pm'
  },
  {
    'name': 'about-program1800',
    'avail': Math.random() * 5,
    'Timestamp': '3pm'
  },
  {
    'name': 'benefits-administration194',
    'avail':  Math.random() * 5,
    'Timestamp': '3pm'
  },
  {
    'name': 'plans5678',
    'avail': Math.random() * 5,
    'Timestamp': '3pm'
  },
  {
    'name': 'plansowners89064',
    'avail':  Math.random() * 5,
    'Timestamp': '3pm'
  },
  {
    'name': 'planstraditional-401k1738',
    'avail': Math.random() * 5,
    'Timestamp': '3pm'
  },
  {
    'name': 'benefits-employeeeducati63',
    'avail':  Math.random() * 5,
    'Timestamp': '3pm'
  },
  {
    'name': 'plansafeharbor86324',
    'avail': Math.random() * 5,
    'Timestamp': '3pm'
  }
]
// AvailText variable to mark the avail either unavailable or available
var availText;
// For loop to loop through every object in the pages
availObjectPages.forEach(function(entry) {
  var name = entry.name;
  var avail = entry.avail;
  var timeStamp = entry.Timestamp;
  var etr = entry.etr;
  if(avail > 1)
  {
    availText = 'available';
  }
  else {
    availText = 'unavailable';
  }
  if(availText == 'unavailable') {
    healthScore -= 5;
    unavailableItems++;
  } else if(availText == 'available'){
    timeStamp = 'N/A';
  }
})


/* LINKS */
// Array to hold all server responses
var serverResponse = [
  "404: Page Not Found",
  "400: Bad Request",
  "Bad Host: Invalid Host Name",
  "Bad URL: Malformed URL",
  "Bad Code: Invalid HTTP Reponse Code",
  "Empty: No content or response code",
  "Timeout: HTTP Request Timed-out",
  "Reset: Host server drops connections"
];
var linksAndLoadPerPage = [
  {
    "linkName": "Homepage",
    "Page": "ada.axa-equitable.com/",
    "AvgPageLoadTime": 4.84,
    "Pageviews": "1,383",
    "BounceRate": "78.81%",
    "%Exit": "73.61%",
    "PageValue": "$0.00",
    "available": Math.random() * 5,
    "timeStamp": "3pm",
    "serverResponse": Math.floor(Math.random() * 8) + 1
  },
  {
    "linkName": "My Accounts Page",
    "Page": "ada.axa-equitable.com/accounts",
    "AvgPageLoadTime": 8.55,
    "Pageviews": 460,
    "BounceRate": "69.67%",
    "%Exit": "62.61%",
    "PageValue": "$0.00",
    "available": Math.random() * 5,
    "timeStamp": "3pm",
    "serverResponse": Math.floor(Math.random() * 8) + 1
  },
  {
    "linkName": "Invest",
    "Page": "ada.axa-equitable.com/invest.cfm",
    "AvgPageLoadTime": 1.16,
    "Pageviews": 50,
    "BounceRate": "68.75%",
    "%Exit": "60.00%",
    "PageValue": "$0.00",
    "available": Math.random() * 5,
    "timeStamp": "3pm",
    "serverResponse": Math.floor(Math.random() * 8) + 1
  },
  {
    "linkName": "About Page",
    "Page": "ada.axa-equitable.com/about-program.cfm",
    "AvgPageLoadTime": 0,
    "Pageviews": 36,
    "BounceRate": "33.33%",
    "%Exit": "30.56%",
    "PageValue": "$0.00",
    "available": Math.random() * 5,
    "timeStamp": "3pm",
    "serverResponse": Math.floor(Math.random() * 8) + 1
  },
  {
    "linkName": "Benefits Page",
    "Page": "ada.axa-equitable.com/benefits-administration.cfm",
    "AvgPageLoadTime": 1.52,
    "Pageviews": 15,
    "BounceRate": "0.00%",
    "%Exit": "33.33%",
    "PageValue": "$0.00",
    "available": Math.random() * 5,
    "timeStamp": "3pm",
    "serverResponse": Math.floor(Math.random() * 8) + 1
  },
  {
    "linkName": "Plan Information Page",
    "Page": "ada.axa-equitable.com/plans.cfm",
    "AvgPageLoadTime": 0,
    "Pageviews": 14,
    "BounceRate": "50.00%",
    "%Exit": "28.57%",
    "PageValue": "$0.00",
    "available": Math.random() * 5,
    "timeStamp": "3pm",
    "serverResponse": Math.floor(Math.random() * 8) + 1
  },
  {
    "linkName": "401K Page",
    "Page": "ada.axa-equitable.com/plans-owners-401k.cfm",
    "AvgPageLoadTime": 0,
    "Pageviews": 12,
    "BounceRate": "80.00%",
    "%Exit": "58.33%",
    "PageValue": "$0.00",
    "available": Math.random() * 5,
    "timeStamp": "3pm",
    "serverResponse": Math.floor(Math.random() * 8) + 1
  },
  {
    "linkName": "My Profile Page",
    "Page": "ada.axa-equitable.com/my-profile.cfm",
    "AvgPageLoadTime": 0,
    "Pageviews": 10,
    "BounceRate": "100.00%",
    "%Exit": "40.00%",
    "PageValue": "$0.00",
    "available": Math.random() * 5,
    "timeStamp": "3pm",
    "serverResponse": Math.floor(Math.random() * 8) + 1
  },
  {
    "linkName": "Employee Benefits",
    "Page": "ada.axa-equitable.com/benefits-employee-education.cfm",
    "AvgPageLoadTime": 0,
    "Pageviews": 9,
    "BounceRate": "50.00%",
    "%Exit": "22.22%",
    "PageValue": "$0.00",
    "available": Math.random() * 5,
    "timeStamp": "3pm",
    "serverResponse": Math.floor(Math.random() * 8) + 1
  },
  {
    "linkName": "Policies Page",
    "Page": "ada.axa-equitable.com/policies.cfm",
    "AvgPageLoadTime": 0,
    "Pageviews": 9,
    "BounceRate": "0.00%",
    "%Exit": "33.33%",
    "PageValue": "$0.00",
    "available": Math.random() * 5,
    "timeStamp": "3pm",
    "serverResponse": Math.floor(Math.random() * 8) + 1
  }
]
// Array of JUST UNAVAILABLE LINKS
var unavailableLinksArray = [];
// For loop to loop through the array of links
linksAndLoadPerPage.forEach(function(entry) {
  var pageViews = entry.PageViews;
  avgPageViews += pageViews;
  var name = entry.Page;
  var avail = entry.available;
  var timeStamp = entry.timeStamp;
  var availText;
  if(avail > 1) {
    availText = 'available';
  }
  else {
    availText = 'unavailable';
  }
  // Gives the object a server response
  if(entry.serverResponse <= 1)
  {
    entry.serverResponse = serverResponse[0];
  }
  else if (entry.serverResponse == 2) {
    entry.serverReponse = serverResponse[1];
  }
  else if(entry.serverResponse == 3) {
    entry.serverResponse = serverResponse[2]
  }
  else if(entry.serverResponse == 4) {
    entry.serverResponse = serverResponse[3];
  }
  else if(entry.serverResponse == 5) {
    entry.serverResponse = serverResponse[4];
  }
  else if(entry.serverResponse == 6) {
    entry.serverResponse = serverResponse[5];
  }
  else if(entry.serverResponse == 7) {
    entry.serverResponse = serverResponse[6];
  }
  else if(entry.serverResponse == 8) {
    entry.serverResponse = serverResponse[7];
  }

  // If unavailable push to the unavailable link array, adjust the health score, and add to the # of unavailable items
  // If available set the downtime to ""
  if(availText == 'unavailable') {
    unavailableLinksArray.push(entry);
    healthScore -= 5;
    unavailableItems++;
  }
  else if(availText == 'available'){
    timeStamp = "";
  }
})
avgPageViews = avgPageViews/10;
console.log("Unavailable Items: " + unavailableItems);
console.log(unavailableLinksArray);

/*JSON OBJECTS FOR E-DELIVERY */

/* Overall E-Delivery Health determined by hard and soft bounces */
var eDeliveryHealth = 100;

var eDelivery =
[
{
  'month':'January',
  'signUps': Math.random() * 1000,
  'hardBounces': Math.random() * 100,
  'softBounces': Math.random() * 100
},
{
  'month':'February',
  'signUps': Math.random() * 1000,
  'hardBounces': Math.random() * 100,
  'softBounces': Math.random() * 100
},
{
  'month':'March',
  'signUps': Math.random() * 1000,
  'hardBounces': Math.random() * 100,
  'softBounces': Math.random() * 100
},
{
  'month':'April',
  'signUps': Math.random() * 1000,
  'hardBounces': Math.random() * 100,
  'softBounces': Math.random() * 100
},
{
  'month':'May',
  'signUps': Math.random() * 1000,
  'hardBounces': Math.random() * 100,
  'softBounces': Math.random() * 100
},
{
  'month':'June',
  'signUps': Math.random() * 1000,
  'hardBounces': Math.random() * 100,
  'softBounces': Math.random() * 100
},
{
  'month':'July',
  'signUps': Math.random() * 1000,
  'hardBounces': Math.random() * 100,
  'softBounces': Math.random() * 100
},
{
  'month':'August',
  'signUps': Math.random() * 1000,
  'hardBounces': Math.random() * 100,
  'softBounces': Math.random() * 100
},
{
  'month':'September',
  'signUps': Math.random() * 1000,
  'hardBounces': Math.random() * 100,
  'softBounces': Math.random() * 100
},
{
  'month':'October',
  'signUps': Math.random() * 1000,
  'hardBounces': Math.random() * 100,
  'softBounces': Math.random() * 100
},
{
  'month':'November',
  'signUps': Math.random() * 1000,
  'hardBounces': Math.random() * 100,
  'softBounces': Math.random() * 100
},
{
  'month':'December',
  'signUps': Math.random() * 1000,
  'hardBounces': Math.random() * 100,
  'softBounces': Math.random() * 100
}];
var eDeliverySignUps = [
  {
    'month':'January',
    'signUps2017': Math.random() * 1000,
    'signUps2018': Math.random() * 1000
  },
  {
    'month':'February',
    'signUps2017': Math.random() * 1000,
    'signUps2018': Math.random() * 1000
  },
  {
    'month':'March',
    'signUps2017': Math.random() * 1000,
    'signUps2018': Math.random() * 1000
  },
  {
    'month':'April',
    'signUps2017': Math.random() * 1000,
    'signUps2018': Math.random() * 1000
  },
  {
    'month':'May',
    'signUps2017': Math.random() * 1000,
    'signUps2018': Math.random() * 1000
  },
  {
    'month':'June',
    'signUps2017': Math.random() * 1000,
    'signUps2018': Math.random() * 1000
  },
  {
    'month':'July',
    'signUps2017': Math.random() * 1000,
    'signUps2018': Math.random() * 1000
  },
  {
    'month':'August',
    'signUps2017': Math.random() * 1000,
    'signUps2018': Math.random() * 1000
  },
  {
    'month':'September',
    'signUps2017': Math.random() * 1000,
    'signUps2018': Math.random() * 1000
  },
  {
    'month':'October',
    'signUps2017': Math.random() * 1000,
    'signUps2018': Math.random() * 1000
  },
  {
    'month':'November',
    'signUps2017': Math.random() * 1000,
    'signUps2018': Math.random() * 1000
  },
  {
    'month':'December',
    'signUps2017': Math.random() * 1000,
    'signUps2018': Math.random() * 1000
  }
];
var eDelivery2018 = [
  {
    'month':'January',
    'emailsSent': Math.random() * 1000
  },
  {
    'month':'February',
    'emailsSent': Math.random() * 1000
  },
  {
    'month':'March',
    'emailsSent': Math.random() * 1000
  },
  {
    'month':'April',
    'emailsSent': Math.random() * 1000
  },
  {
    'month':'May',
    'emailsSent': Math.random() * 1000
  },
  {
    'month':'June',
    'emailsSent': Math.random() * 1000
  },
  {
    'month':'July',
    'emailsSent': Math.random() * 1000
  },
  {
    'month':'August',
    'emailsSent': Math.random() * 1000
  },
  {
    'month':'September',
    'emailsSent': Math.random() * 1000
  },
  {
    'month':'October',
    'emailsSent': Math.random() * 1000
  },
  {
    'month':'November',
    'emailsSent': Math.random() * 1000
  },
  {
    'month':'December',
    'emailsSent': Math.random() * 1000
  }
];

eDelivery.forEach(function(entry) {
  var month = entry.month;
  var emailsSent = entry.emailsSent;
  var hardBounces = entry.hardBounces;
  var softBounces = entry.softBounces;
  var totalBounces = hardBounces + softBounces;
  switch (true) {
  case totalBounces > 1000:
     eDeliveryHealth = eDeliveryHealth - 30;
     break;
  case totalBounces > 500:
     eDeliveryHealth = eDeliveryHealth - 15;
     break;
  case totalBounces > 100:
      eDeliveryHealth = eDeliveryHealth - 10;
      break;
  default:
      eDeliveryHealth = 100;
    }
})
console.log("eDelivery Health: " + eDeliveryHealth);


/* JSON OBJECTS FOR BROWSERS */
/* BROWSERS */
var browsers = [
  {
    "Browser": "Chrome",
    "Users": 474,
    "NewUsers": 191,
    "Sessions": 680,
    "BounceRate": "73.97%",
    "PagesSession": 1.52,
    "AvgSessionDuration": "00:02:45",
    "GoalConversionRate": "0.00%",
    "GoalCompletions": 0,
    "GoalValue": "$0.00"
  },
  {
    "Browser": "Internet Explorer",
    "Users": 211,
    "NewUsers": 92,
    "Sessions": 294,
    "BounceRate": "80.27%",
    "PagesSession": 1.35,
    "AvgSessionDuration": "00:02:14",
    "GoalConversionRate": "0.00%",
    "GoalCompletions": 0,
    "GoalValue": "$0.00"
  },
  {
    "Browser": "Safari",
    "Users": 169,
    "NewUsers": 89,
    "Sessions": 226,
    "BounceRate": "73.45%",
    "PagesSession": 1.51,
    "AvgSessionDuration": "00:01:37",
    "GoalConversionRate": "0.00%",
    "GoalCompletions": 0,
    "GoalValue": "$0.00"
  },
  {
    "Browser": "Edge",
    "Users": 84,
    "NewUsers": 38,
    "Sessions": 114,
    "BounceRate": "85.09%",
    "PagesSession": 1.4,
    "AvgSessionDuration": "00:02:06",
    "GoalConversionRate": "0.00%",
    "GoalCompletions": 0,
    "GoalValue": "$0.00"
  },
  {
    "Browser": "Firefox",
    "Users": 64,
    "New Users": 32,
    "Sessions": 92,
    "BounceRate": "80.43%",
    "PagesSession": 1.34,
    "AvgSessionDuration": "00:01:14",
    "GoalConversionRate": "0.00%",
    "GoalCompletions": 0,
    "GoalValue": "$0.00"
  },
  {
    "Browser": "Samsung Internet",
    "Users": 2,
    "New Users": 0,
    "Sessions": 2,
    "BounceRate": "50.00%",
    "PagesSession": 2.5,
    "AvgSessionDuration": "00:00:52",
    "GoalConversionRate": "0.00%",
    "GoalCompletions": 0,
    "GoalValue": "$0.00"
  },
  {
    "Browser": "Amazon Silk",
    "Users": 1,
    "NewUsers": 1,
    "Sessions": 1,
    "BounceRate": "0.00%",
    "PagesSession": 12,
    "AvgSessionDuration": "00:15:38",
    "GoalConversionRate": "0.00%",
    "GoalCompletions": 0,
    "GoalValue": "$0.00"
  },
  {
    "Browser": "Opera",
    "Users": 1,
    "NewUsers": 0,
    "Sessions": 4,
    "BounceRate": "100.00%",
    "PagesSession": 1,
    "AvgSessionDuration": "00:00:00",
    "GoalConversionRate": "0.00%",
    "GoalCompletions": 0,
    "GoalValue": "$0.00"
  }
]

/*Devices */
var devices = [
  {
    "DeviceCategory": "Desktop",
    "Users": 879,
    "NewUsers": 365,
    "Sessions": "1,242",
    "BounceRate": "77.78%",
    "PagesSession": 1.41,
    "AvgSessionDuration": "00:02:19",
    "GoalConversionRate": "0.00%",
    "GoalCompletions": 0,
    "GoalValue": "$0.00"
  },
  {
    "DeviceCategory": "Tablet",
    "Users": 67,
    "NewUsers": 35,
    "Sessions": 87,
    "BounceRate": "79.31%",
    "PagesSession": 1.55,
    "AvgSessionDuration": "00:02:42",
    "GoalConversionRate": "0.00%",
    "GoalCompletions": 0,
    "GoalValue": "$0.00"
  },
  {
    "DeviceCategory": "Mobile",
    "Users": 60,
    "NewUsers": 43,
    "Sessions": 84,
    "BounceRate": "54.76%",
    "PagesSession": 2.24,
    "AvgSessionDuration": "00:01:39",
    "GoalConversionRate": "0.00%",
    "GoalCompletions": 0,
    "GoalValue": "$0.00"
  }
];
console.log("Overall Health: " + healthScore);

//Insert calls

var pageName = availObjectPages.name
document.getElementById('pageName').innerHTML = pageName;//$("#pageName").text(availObjectPages.name); // page 1 - table 1 -  line 1
$("#pageAvail").text(availObjectPages.avail); // page 1 - table 1 - line 2
// insert class of "font-red" or "font-green" depending on pageAvail
$("#pageDown").text(availObjectPages.timeStamp); // page 1 - table 1 - line 3
// --------
$("#linkName").text(linksAndLoadPerPage.linkName); // page 1 - table 2 - line 1
$("#linkURL").text(linksAndLoadPerPage.Page); // page 1 - table 2 - line 2
$("#serverResponse").text(linksAndLoadPerPage.serverReponse); // page 1 - table 2 - line 3
// --------
// insert class of "font-red", "font-orange" or "font-green" depending on score break points
var healthscore = healthScore;
document.getElementById('pageName').innerHTML(healthscore + '%'); //$("#healthscore").append(healthScore); // page 1 - box 1
$("#avgLoad").append(overallAvgLoad); // page 1 - box 2
$("#unavailableItems").append(unavailableItems); // page 1 - box 3
$("#views").append(pageViews); // page 1 - box 4
// --------
$("#activeUsers").text(availObjectPages.name); // page 3 - box 1

// For Loop
var text = "";
var i = 0;
for (i; i < availObjectPages.length; i++) {
  text += "<tr><td>" + linkName + "</td><td>" + Page + "</td><td>" + serverResponse + "</td></tr>"
}

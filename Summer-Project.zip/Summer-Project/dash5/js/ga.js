// INFO FROM GOOGLE ANALYTICS 

/* USERS BY WEEK */
var usersWeekly = [
  {
    "Day Index": "6/21/18",
    "Users": 199
  },
  {
    "Day Index": "6/22/18",
    "Users": 193
  },
  {
    "Day Index": "6/23/18",
    "Users": 101
  },
  {
    "Day Index": "6/24/18",
    "Users": 92
  },
  {
    "Day Index": "6/25/18",
    "Users": 245
  },
  {
    "Day Index": "6/26/18",
    "Users": 221
  },
  {
    "Day Index": "6/27/18",
    "Users": 222
  }
]

/* BROWSERS */
var browsers = [
  {
    "Browser": "Chrome",
    "Users": 474,
    "New Users": 191,
    "Sessions": 680,
    "Bounce Rate": "73.97%",
    "Pages / Session": 1.52,
    "Avg. Session Duration": "00:02:45",
    "Goal Conversion Rate": "0.00%",
    "Goal Completions": 0,
    "Goal Value": "$0.00"
  },
  {
    "Browser": "Internet Explorer",
    "Users": 211,
    "New Users": 92,
    "Sessions": 294,
    "Bounce Rate": "80.27%",
    "Pages / Session": 1.35,
    "Avg. Session Duration": "00:02:14",
    "Goal Conversion Rate": "0.00%",
    "Goal Completions": 0,
    "Goal Value": "$0.00"
  },
  {
    "Browser": "Safari",
    "Users": 169,
    "New Users": 89,
    "Sessions": 226,
    "Bounce Rate": "73.45%",
    "Pages / Session": 1.51,
    "Avg. Session Duration": "00:01:37",
    "Goal Conversion Rate": "0.00%",
    "Goal Completions": 0,
    "Goal Value": "$0.00"
  },
  {
    "Browser": "Edge",
    "Users": 84,
    "New Users": 38,
    "Sessions": 114,
    "Bounce Rate": "85.09%",
    "Pages / Session": 1.4,
    "Avg. Session Duration": "00:02:06",
    "Goal Conversion Rate": "0.00%",
    "Goal Completions": 0,
    "Goal Value": "$0.00"
  },
  {
    "Browser": "Firefox",
    "Users": 64,
    "New Users": 32,
    "Sessions": 92,
    "Bounce Rate": "80.43%",
    "Pages / Session": 1.34,
    "Avg. Session Duration": "00:01:14",
    "Goal Conversion Rate": "0.00%",
    "Goal Completions": 0,
    "Goal Value": "$0.00"
  },
  {
    "Browser": "Samsung Internet",
    "Users": 2,
    "New Users": 0,
    "Sessions": 2,
    "Bounce Rate": "50.00%",
    "Pages / Session": 2.5,
    "Avg. Session Duration": "00:00:52",
    "Goal Conversion Rate": "0.00%",
    "Goal Completions": 0,
    "Goal Value": "$0.00"
  },
  {
    "Browser": "Amazon Silk",
    "Users": 1,
    "New Users": 1,
    "Sessions": 1,
    "Bounce Rate": "0.00%",
    "Pages / Session": 12,
    "Avg. Session Duration": "00:15:38",
    "Goal Conversion Rate": "0.00%",
    "Goal Completions": 0,
    "Goal Value": "$0.00"
  },
  {
    "Browser": "Opera",
    "Users": 1,
    "New Users": 0,
    "Sessions": 4,
    "Bounce Rate": "100.00%",
    "Pages / Session": 1,
    "Avg. Session Duration": "00:00:00",
    "Goal Conversion Rate": "0.00%",
    "Goal Completions": 0,
    "Goal Value": "$0.00"
  }
]

/*Devices */
var devices = [
  {
    "Device Category": "desktop",
    "Users": 879,
    "New Users": 365,
    "Sessions": "1,242",
    "Bounce Rate": "77.78%",
    "Pages / Session": 1.41,
    "Avg. Session Duration": "00:02:19",
    "Goal Conversion Rate": "0.00%",
    "Goal Completions": 0,
    "Goal Value": "$0.00"
  },
  {
    "Device Category": "tablet",
    "Users": 67,
    "New Users": 35,
    "Sessions": 87,
    "Bounce Rate": "79.31%",
    "Pages / Session": 1.55,
    "Avg. Session Duration": "00:02:42",
    "Goal Conversion Rate": "0.00%",
    "Goal Completions": 0,
    "Goal Value": "$0.00"
  },
  {
    "Device Category": "mobile",
    "Users": 60,
    "New Users": 43,
    "Sessions": 84,
    "Bounce Rate": "54.76%",
    "Pages / Session": 2.24,
    "Avg. Session Duration": "00:01:39",
    "Goal Conversion Rate": "0.00%",
    "Goal Completions": 0,
    "Goal Value": "$0.00"
  }
]

/* LOAD TIMES */
var avgLoadPerDay = [
  {
    "Day Index": "6/21/18",
    "Avg. Page Load Time (sec)": 3.49
  },
  {
    "Day Index": "6/22/18",
    "Avg. Page Load Time (sec)": 0
  },
  {
    "Day Index": "6/23/18",
    "Avg. Page Load Time (sec)": 5.27
  },
  {
    "Day Index": "6/24/18",
    "Avg. Page Load Time (sec)": 4.65
  },
  {
    "Day Index": "6/25/18",
    "Avg. Page Load Time (sec)": 3.73
  },
  {
    "Day Index": "6/26/18",
    "Avg. Page Load Time (sec)": 0
  },
  {
    "Day Index": "6/27/18",
    "Avg. Page Load Time (sec)": 4.74
  }
]
var loadPerPage = [
  {
    "Page": "ada.axa-equitable.com/",
    "Avg. Page Load Time (sec)": 4.84,
    "Pageviews": "1,383",
    "Bounce Rate": "78.81%",
    "% Exit": "73.61%",
    "Page Value": "$0.00"
  },
  {
    "Page": "ada.axa-equitable.com/default.cfm",
    "Avg. Page Load Time (sec)": 8.55,
    "Pageviews": 460,
    "Bounce Rate": "69.67%",
    "% Exit": "62.61%",
    "Page Value": "$0.00"
  },
  {
    "Page": "ada.axa-equitable.com/invest.cfm",
    "Avg. Page Load Time (sec)": 1.16,
    "Pageviews": 50,
    "Bounce Rate": "68.75%",
    "% Exit": "60.00%",
    "Page Value": "$0.00"
  },
  {
    "Page": "ada.axa-equitable.com/about-program.cfm",
    "Avg. Page Load Time (sec)": 0,
    "Pageviews": 36,
    "Bounce Rate": "33.33%",
    "% Exit": "30.56%",
    "Page Value": "$0.00"
  },
  {
    "Page": "ada.axa-equitable.com/benefits-administration.cfm",
    "Avg. Page Load Time (sec)": 1.52,
    "Pageviews": 15,
    "Bounce Rate": "0.00%",
    "% Exit": "33.33%",
    "Page Value": "$0.00"
  },
  {
    "Page": "ada.axa-equitable.com/plans.cfm",
    "Avg. Page Load Time (sec)": 0,
    "Pageviews": 14,
    "Bounce Rate": "50.00%",
    "% Exit": "28.57%",
    "Page Value": "$0.00"
  },
  {
    "Page": "ada.axa-equitable.com/plans-owners-401k.cfm",
    "Avg. Page Load Time (sec)": 0,
    "Pageviews": 12,
    "Bounce Rate": "80.00%",
    "% Exit": "58.33%",
    "Page Value": "$0.00"
  },
  {
    "Page": "ada.axa-equitable.com/plans-traditional-401k.cfm",
    "Avg. Page Load Time (sec)": 0,
    "Pageviews": 10,
    "Bounce Rate": "100.00%",
    "% Exit": "40.00%",
    "Page Value": "$0.00"
  },
  {
    "Page": "ada.axa-equitable.com/benefits-employee-education.cfm",
    "Avg. Page Load Time (sec)": 0,
    "Pageviews": 9,
    "Bounce Rate": "50.00%",
    "% Exit": "22.22%",
    "Page Value": "$0.00"
  },
  {
    "Page": "ada.axa-equitable.com/plans-safe-harbor-401k.cfm",
    "Avg. Page Load Time (sec)": 0,
    "Pageviews": 9,
    "Bounce Rate": "0.00%",
    "% Exit": "33.33%",
    "Page Value": "$0.00"
  }
]
